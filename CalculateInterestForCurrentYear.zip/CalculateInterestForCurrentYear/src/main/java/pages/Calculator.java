package pages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import base.Base;


public class Calculator extends Base{
	public XSSFWorkbook workbook;
	public FileOutputStream fo;
	
	public void clickOnCarLoan() {
		//Calling Url From Base class
		openUrl();
		//Using Actions class to perform click on the Web Element carLoan
		WebElement carLoan = driver.findElement(By.xpath("//li[@id=\"car-loan\"]"));
		Actions action=new Actions(driver);
		action.moveToElement(carLoan).click().perform();
	}
	
	//carEmi Method to Calculate Car Loan
	public void carEmi() throws InterruptedException {
		//Finding the WebElement Loan Amount
		driver.findElement(By.id("loanamount"));
		
		//Using the Actions class To Perform DragandDrop
		//Setting the Loan Amount To 1500000
		WebElement amtSlider=driver.findElement(By.xpath("//*[@id='loanamountslider']/span"));
		Actions act = new Actions(driver);
		act.dragAndDropBy(amtSlider, 353,0).perform();
		Thread.sleep(5000);
		
		//Setting the Interest Amount To 9.5
		WebElement intSlider=driver.findElement(By.xpath("//*[@id='loaninterestslider']/span"));
		act.dragAndDropBy(intSlider, 40,0).perform();
		
		//Setting the Loan Tenure to 1 Year
		driver.findElement(By.id("loanterm")).clear();
		Thread.sleep(5000);
		
		//Scrolling down to the WebTable 
		JavascriptExecutor jse=(JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,4000)");
		
		//Clicking on the Year 2023 to Extract the monthly Principal and Interest Amount
		WebElement clickYear=driver.findElement(By.id("year2023"));
		clickYear.click();
		
		//Saving the monthly Principal and Interest Amount in principal and interest variables
		//And Printing Principal and Interest Amount for the month
		String principal=driver.findElement(By.xpath("//*[@id=\"monthyear2023\"]/td/div/table/tbody/tr[1]/td[2]")).getText();
		String interest=driver.findElement(By.xpath("//*[@id=\"monthyear2023\"]/td/div/table/tbody/tr[1]/td[3]")).getText();
		System.out.println("The Principal amount for the month is "+principal+"\nInterest amount for the month is "+interest);
		//reportPass("Interest and Principal amount are obtained");
	}
	
	public void homeEmi() throws InterruptedException, IOException, InvalidFormatException {
		//Scrolling back up to the Calculators 
		JavascriptExecutor jse=(JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,0)");
		
		//Clicking the Calculator to get Drop Down Menu
		//And Clicking on the Home Loan Calculator
		driver.findElement(By.id("menu-item-dropdown-2696")).click();
		driver.findElement(By.xpath("//*[@id=\"menu-item-3294\"]/a")).click();
		Thread.sleep(7000);
		
		//Clearing the Amount and Setting value of 4000000
		driver.findElement(By.id("homeprice")).clear();
		driver.findElement(By.id("homeprice")).sendKeys("4000000");
		
		//Scrolling down to the Web Table
		//Finding the WebTable
		jse.executeScript("window.scrollBy(0,2300)");
		Thread.sleep(3000);
		WebElement table=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody"));
		//Extracting Total Number of Rows
		int rows=driver.findElements(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr")).size();
		Calculator wtte=new Calculator();
		
		//looping over the rows to Extract the cell values with its respective Columns
		//Getting the cell Values from the WebTable
		for(int i=1;i<=rows-22;i++) {
			String year=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[1]")).getText();
			String Principal=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[2]")).getText();
			String Interest=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[3]")).getText();
			String Taxes=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[4]")).getText();
			String TotalPayment=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[5]")).getText();
			String Balance=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[6]")).getText();
			String Loanpaidtodate=driver.findElement(By.xpath("//*[@id=\"paymentschedule\"]/table/tbody/tr["+i*2+"]/td[7]")).getText();
			
			System.out.println(year+" " + Principal+" "+Interest+" "+Taxes+" "+TotalPayment+" "+Balance+" ");
			//Calling the setCellData 
			//passing the Sheet name, row, column, data to the setCellData
			wtte.setCellData("YearTable", i, 0, year);
			wtte.setCellData("YearTable", i, 1, Principal);
			wtte.setCellData("YearTable", i, 2, Interest);
			wtte.setCellData("YearTable", i, 3, Taxes);
			wtte.setCellData("YearTable", i, 4, TotalPayment);
			wtte.setCellData("YearTable", i, 5, Balance);
			wtte.setCellData("YearTable", i, 6, Loanpaidtodate);
		}
		//Printing  the completion of the Extraction
		System.out.println("Extraction is Done");
		//reportPass("Table data is stored in the excel");
	}
	
	public void setCellData(String sheetName, int rownum, int colnum, String data) throws IOException {
		//Creating a file
		//Passing the path for the Excel sheet
		File file=new File(".\\src\\test\\resources\\Table.xlsx");
		//Checking if File exists
		//If exist's then the FileInputStream is used 
		//If Does'nt exist then file is created 
		if(!file.exists()) {
			workbook=new XSSFWorkbook();
			fo=new FileOutputStream(".\\src\\test\\resources\\Table.xlsx");
			workbook.write(fo);
		}
		//Initiating the WorkBook 
		//If sheet does'nt exist then Sheet is created
		FileInputStream fi=new FileInputStream(".\\src\\test\\resources\\Table.xlsx");
		workbook=new XSSFWorkbook(fi);
		if(workbook.getSheetIndex(sheetName)==-1) {
			workbook.createSheet(sheetName);
		}
		//Checking if the rows are present in the sheet
		//Creating rows if the rows are not present
		XSSFSheet sheet=workbook.getSheet(sheetName);
		if(sheet.getRow(rownum)==null) {
			sheet.createRow(rownum);
		}
		//Creating a cell and setting value to the cell
		//Using FileOutputStream to Write the data
		//Closing WorkBook
		//Then Closing the InputStream and OutputStream File
		XSSFRow row=sheet.getRow(rownum);
		XSSFCell cell=row.createCell(colnum);
		cell.setCellValue(data);
		fo=new FileOutputStream(".\\src\\test\\resources\\Table.xlsx");
		workbook.write(fo);
		workbook.close();
		fi.close();
		fo.close();
	}
	
	public void scale() {
		//Using List to get the scale range values
		//Looping over it and printing the Scale Values
		List<WebElement> scaleEle=driver.findElements(By.xpath("//*[@id='loantermsteps']/span/span"));
		for(int i=0;i<scaleEle.size();i++) {
			scaleEle.get(i).getText();
			System.out.println(scaleEle.get(i).getText());
		}
	}
	
	public void loan() throws InterruptedException {
		//Clicking on the Calculator 
		//Clicking on Loan Calculator
		driver.findElement(By.id("menu-item-dropdown-2696")).click();
		driver.findElement(By.xpath("//*[@id=\"menu-item-2423\"]/a")).click();
		
		String totalPayable1=driver.findElement(By.xpath("//*[@id=\"loanpaymenttable\"]/table/tbody/tr[2]/td[4]")).getText();
		
		Thread.sleep(5000);
		//Deleting the Loan Amount and Setting value to 2000000
		WebElement loanamt=driver.findElement(By.xpath("//*[@id=\"loanamount\"]"));
		loanamt.sendKeys(Keys.chord(Keys.CONTROL,"a",Keys.DELETE));
		driver.findElement(By.xpath("//*[@id=\"loanamount\"]")).sendKeys("2000000");
		
		//Changing the Interest Rate Scale
		WebElement lamtslider=driver.findElement(By.xpath("//*[@id='loaninterestslider']/span"));
		Actions action=new Actions(driver);
		action.dragAndDropBy(lamtslider, 35, 0).perform();
		Thread.sleep(3000);
		String totalPayable2=driver.findElement(By.xpath("//*[@id=\"loanpaymenttable\"]/table/tbody/tr[2]/td[4]")).getText();
		
		//Printing the totalAmount payable before and after the changes
		System.out.println("Checking if the Total Amount Payable is changing by changing the principal amount");
		System.out.println("Total Amount Payable for 1000000 : "+totalPayable1+"\nTotal Amount Payable for 2000000 : "+totalPayable2);
		
		//Printing the year scale for EMI calculator
		System.out.println("Year Scale:");
		scale();
		Thread.sleep(2000);
		
		//Changing the tenure to months
		//printing the month scale
		action.moveToElement(driver.findElement(By.xpath("//label[text()='Mo ']"))).click().perform();
		System.out.println("Month Scale:");
		scale();
		Thread.sleep(2000);
		
		//Clicking on Loan Amount Calculator
		//Printing the month Scale and Year Scale of the Loan Amount Calculator
		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"loan-amount-calc\"]/a[1]"))).click().perform();
		System.out.println("Month Scale in LoanAmountCal:");
		scale();
		Thread.sleep(2000);
		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"ltermwrapper\"]/div[1]/div/div/div/div/div/label[1]"))).click().perform();
		System.out.println("Year Scale in LoanAmountCal");
		scale();
		Thread.sleep(2000);
		
		//Clicking on Loan Tenure Calculator
		//Checking the change in Loan Tenure before and after changing the EMI
		//Using DragandDrop to Change the EMI
		action.moveToElement(driver.findElement(By.xpath("//*[@id=\"loan-tenure-calc\"]/a[1]"))).click().perform();
		System.out.println("Loan Tenure before changing EMI : "+driver.findElement(By.xpath("//*[@id=\"loansummary-tenure\"]/p/span")).getText());
		WebElement emi=driver.findElement(By.xpath("//*[@id=\"loanemislider\"]/span"));
		action.dragAndDropBy(emi, 58, 0).perform();
		Thread.sleep(3000);
		
		//Printing the Change in Loan Tenure 
		System.out.println("Loan Tenure after changing EMI : "+driver.findElement(By.xpath("//*[@id=\"loansummary-tenure\"]/p/span")).getText());
		//reportPass("Loan Calcutaor fields are checked and amount changed is obtained");
	}
}