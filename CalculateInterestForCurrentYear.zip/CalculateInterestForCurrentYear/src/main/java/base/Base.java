package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.ExtentReport;

public class Base {
	public WebDriver driver;
	public Properties prop;
	public FileInputStream fis;
	public WebDriverWait wait;
	public static ExtentTest logger;
	public ExtentReports report=ExtentReport.getReportInstance();
	
	public void browserSetup() throws FileNotFoundException, IOException {
		
		//Declaring Properties File 
		//And Loading the Config file
		fis=new FileInputStream("C:\\eclipse workspace\\CalculateInterestForCurrentYear\\src\\main\\java\\utilities\\PropertiesFile");
		prop=new Properties();
		prop.load(fis);
		
		//Getting the Browser Name from Properties File
		//Invoking respective Browser
		if(prop.getProperty("BrowserName").equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
		}
		else if(prop.getProperty("BrowserName").equalsIgnoreCase("edge")) {
			WebDriverManager.edgedriver().setup();
			driver=new EdgeDriver();
		}
		//Maximizing the Window
		driver.manage().window().maximize();
		
	}
	public void openUrl() {
		driver.get(prop.getProperty("WebSiteUrl"));
	 }
	 
	public void reportFail(String report) {
		logger.log(Status.FAIL, report);
	}
	
	public void reportPass(String report) {
		logger.log(Status.PASS, report);
	}
	
	public void endReport() {
		report.flush();
	}
	
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
		driver.quit();
	}
}
