package tests;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.Base;
import pages.Calculator;


public class Tests extends Base {
	
	Calculator c=new Calculator();
	
	@BeforeTest
	public void invokeBrowser() throws FileNotFoundException, IOException {
		logger = report.createTest("Execution of Test Cases");
		c.browserSetup();
		reportPass("Browser is Invoked");
	}
	@Test(priority=0)
	public void clickCarLoan() {
		c.clickOnCarLoan();
	}
	@Test(priority=1)
	public void calCarEmi() throws InterruptedException {
		c.carEmi();
		reportPass("Interest and principal amounts are retrieved");
	}
	@Test(priority=2)
	public void CalHomeEmi() throws InvalidFormatException, InterruptedException, IOException {
		c.homeEmi();
		reportPass("Home loan structured is obtained and stored in excel");
	}
	@Test(priority=3)
	public void CalLoan() throws InterruptedException {
		c.loan();
		reportPass("Loan Calcutaor fields are checked and amount changed is obtained");
	}
	@AfterTest
	public void closeBrowser() throws InterruptedException {
		c.endReport();
		c.closeBrowser();
	}
	
}

